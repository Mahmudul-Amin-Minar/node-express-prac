const express = require('express');
const multer = require('multer');
const dotenv = require('dotenv');
dotenv.config();

const { minioUploader,minioBuckets } = require('./file-uploader');

const app = express();

const storage = multer.memoryStorage();

const upload = multer({
    storage,
});

// app.post('/upload', upload.single('file'), async(req, res) => {
//     const file = req.file;
//     console.log(file);
//     const result = await minioUploader(file);
//     res.json({status: 'success', result});
// });

app.post('/upload', upload.single('file'), minioUploader);

app.get('/list-bucket', minioBuckets);

app.listen(3000, () => console.log('listening to port 3000'));