var Minio = require('minio');
var fs = require('fs');


var minioClient = new Minio.Client({
    endPoint: process.env.ENDPOINT,
    port: 9000 || process.env.PORT,
    useSSL: false,
    accessKey: process.env.ACCESS_KEY,
    secretKey: process.env.SECRET_KEY,
});


const minioUploader = async(req, res, next) => {

    await minioClient.bucketExists("files", async function(err, exists) {
        if (err) {
          return console.log(err)
        }
        if (!exists) {
            await minioClient.makeBucket("files", 'us-east-1', function(err){
                if(err){
                    return console.log(err);
                }
                return console.log('Bucket created successfully in "us-east-1"');
            });
        }else{
            return console.log('bucket exist');
        }
    })
    console.log('minio uploader function scope');
    

    var metaData = {
        'Content-Type': 'application/octet-stream',
        'X-Amx-Meta-Testing': 1234,
        'example': 5678
    }
    var file = req.file;

    // minioClient.fPutObject('images', '1.jpg', file, metaData, function(err, etag){
    //     if(err){
    //         return console.log(err);
    //     }
    //     console.log('File uploaded successfully');
    // });
    // Upload a buffer
    await minioClient.putObject("files", file.originalname, file.buffer, metaData, function(e, objinfo) {
        if (e) {
            res.json({
                error: e
            })
        }else{
            console.log("Successfully uploaded the buffer")
            res.json({
                obj: objinfo
            })
        }
    })
    console.log('after putobject');
    //});
}

const minioBuckets = async(req, res) => {
    minioClient.listBuckets((err, buckets) => {
        if(err){
            res.status(400).json({
                error: err
              });
        }
        res.status(200).json({
            result: buckets
        });
    })
}

module.exports = {
    minioUploader,
    minioBuckets,
}