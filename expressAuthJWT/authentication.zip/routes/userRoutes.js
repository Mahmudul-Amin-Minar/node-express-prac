import express from 'express';

import UserController from '../controllers/userController.js';
import checkUserAuth from '../middlewares/auth-middleware.js';
import { RegistrationValidations, RegistrationValidationsHandler } from '../middlewares/registration-validation.js';


const router = express.Router();

// Public Routes
router.post('/register', RegistrationValidations, RegistrationValidationsHandler, UserController.userRegistration);
router.post('/login', UserController.userLogin);
router.post('/send-reset-password-email', UserController.sendUserPasswordResetEmail);
router.post('/reset-password/:id/:token', UserController.userPasswordReset);

// Protected Routes
router.post('/change-password', checkUserAuth,  UserController.changeUserPassword);
router.get('/logged-user', checkUserAuth,  UserController.loggedUser);

export default router;