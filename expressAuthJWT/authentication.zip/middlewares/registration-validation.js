import { check, validationResult } from "express-validator";
import createError from "http-errors";

import User from '../models/User.js';

export const RegistrationValidations = [
    check("name", "Name is required").isLength({ min: 1 }).isAlpha("en-US", { ignore: " -" }).withMessage("Name must not contain anything other than alphabet").trim(),
    check("email", "Invalid email address").isEmail().trim().custom(async (value) => {
        try {
            const user = await User.findOne({ email: value });
            if (user) {
                throw createError("Email already is use!");
            }
        } catch (err) {
            throw createError(err.message);
        }
    }),
    check("mobile").isMobilePhone("bn-BD").withMessage("Mobile number must be a valid Bangladeshi mobile number").custom(async (value) => {
        try {
            const user = await User.findOne({ mobile: value });
            if (user) {
                throw createError("Mobile already is use!");
            }
        } catch (err) {
            throw createError(err.message);
        }
    }),
    check("password").isLength({min: 6}).withMessage("Password must be at least 6 character"),
]

export const RegistrationValidationsHandler = function (req, res, next) {
  const errors = validationResult(req);
  const mappedErrors = errors.mapped();
  if (Object.keys(mappedErrors).length === 0) {
    next();
  } else {
    res.status(500).json({
      errors: mappedErrors,
    });
  }
};

