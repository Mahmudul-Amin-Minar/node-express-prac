const cors = require('cors');
const dotenv = require('dotenv');
const express = require('express');

const data = require('./data/CourseModule.json');


dotenv.config()

const app = express();
const port = process.env.PORT;

app.use(cors());
app.use(express.json());

app.get('/api/course', (req, res) => {
    res.json(data);
})
app.get('/', (req, res) => {
    res.send({
        message: "Course Module"
    });
})

app.listen(port, () => {
    console.log(`server running at http://localhost:${port}`);
})